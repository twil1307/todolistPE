import ToDoList from "./TodoList/ToDoList";

function App() {
  return (
    <div className="container">
      <ToDoList />
    </div>
  );
}

export default App;
