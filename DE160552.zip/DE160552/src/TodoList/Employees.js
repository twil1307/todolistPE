export const data = [
  { name: "Nguyen Van Minh A", gpa: 3.5, dob: "1988-07-14" },
  { name: "Phan Van Le B", gpa: 3.9, dob: "2000-02-12" },
  { name: "Nguyen Van C", gpa: 3.2, dob: "2001-02-28" },
  { name: "Hoang Dung Dinh B", gpa: 3.4, dob: "1989-05-12" },
];

// export const data = [
//   {
//     id: "e1",
//     name: "Nguyen Van Minh A",
//     gpa: 3.5,
//     date: new Date(1988, 7, 14),
//   },
//   { id: "e2", name: "Phan Van Le B", gpa: 3.9, date: new Date(2000, 2, 12) },
//   {
//     id: "e3",
//     name: "Tran Thanh Tan C",
//     gpa: 3.2,
//     date: new Date(2001, 2, 28),
//   },
//   {
//     id: "e4",
//     name: "Hoang Dung Dinh B",
//     gpa: 3.4,
//     date: new Date(1989, 5, 12),
//   },
// ];
